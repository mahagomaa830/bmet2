import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Download, Upload, HardDrive, Package, FileText, Database, Settings } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function AdminDashboard() {
  const { toast } = useToast();
  const [isExporting, setIsExporting] = useState(false);
  const [isBackingUp, setIsBackingUp] = useState(false);

  const handleExport = async (type: 'equipment' | 'maintenance' | 'faults' | 'project-zip') => {
    try {
      setIsExporting(true);
      
      const response = await fetch(`/api/export/${type}`);
      if (!response.ok) throw new Error('Export failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      
      if (type === 'project-zip') {
        a.download = 'medical-equipment-system.zip';
      } else {
        const filename = type === 'equipment' ? 'الأجهزة_الطبية.xlsx' :
                        type === 'maintenance' ? 'سجلات_الصيانة.xlsx' :
                        'تقارير_الأعطال.xlsx';
        a.download = filename;
      }
      
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "نجح التصدير",
        description: type === 'project-zip' ? "تم تحميل ملف المشروع كاملاً" : "تم تحميل الملف بنجاح",
      });
    } catch (error) {
      toast({
        title: "فشل التصدير",
        description: "حدث خطأ أثناء تصدير البيانات",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleImport = (type: 'equipment' | 'maintenance') => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx,.xls';
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      try {
        const formData = new FormData();
        formData.append('file', file);

        const response = await fetch(`/api/import/${type}`, {
          method: 'POST',
          body: formData,
        });

        if (!response.ok) throw new Error('Import failed');
        const result = await response.json();

        toast({
          title: "نجح الاستيراد",
          description: `تم استيراد ${result.imported || 0} عنصر بنجاح`,
        });
      } catch (error) {
        toast({
          title: "فشل الاستيراد",
          description: "حدث خطأ أثناء استيراد البيانات",
          variant: "destructive",
        });
      }
    };
    input.click();
  };

  const handleDriveBackup = async () => {
    try {
      setIsBackingUp(true);
      await apiRequest('/api/drive/backup', { method: 'POST' });
      
      toast({
        title: "نجحت النسخة الاحتياطية",
        description: "تم رفع البيانات إلى Google Drive بنجاح",
      });
    } catch (error) {
      toast({
        title: "فشلت النسخة الاحتياطية",
        description: "تأكد من إعداد مفاتيح Google Drive API",
        variant: "destructive",
      });
    } finally {
      setIsBackingUp(false);
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6 max-w-6xl" dir="rtl">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">لوحة تحكم المدير</h1>
        <p className="text-muted-foreground">
          إدارة النظام والبيانات ونسخ احتياطية
        </p>
      </div>

      {/* Export Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            تصدير البيانات
          </CardTitle>
          <CardDescription>
            تحميل البيانات بصيغة Excel أو تحميل المشروع كاملاً
          </CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Button
            onClick={() => handleExport('equipment')}
            disabled={isExporting}
            variant="outline"
            className="h-20 flex flex-col gap-2"
          >
            <Settings className="h-6 w-6" />
            الأجهزة الطبية
          </Button>
          
          <Button
            onClick={() => handleExport('maintenance')}
            disabled={isExporting}
            variant="outline"
            className="h-20 flex flex-col gap-2"
          >
            <FileText className="h-6 w-6" />
            سجلات الصيانة
          </Button>
          
          <Button
            onClick={() => handleExport('faults')}
            disabled={isExporting}
            variant="outline"
            className="h-20 flex flex-col gap-2"
          >
            <Database className="h-6 w-6" />
            تقارير الأعطال
          </Button>
          
          <Button
            onClick={() => handleExport('project-zip')}
            disabled={isExporting}
            variant="default"
            className="h-20 flex flex-col gap-2"
          >
            <Package className="h-6 w-6" />
            المشروع كاملاً
            <Badge variant="secondary" className="text-xs">
              ZIP
            </Badge>
          </Button>
        </CardContent>
      </Card>

      {/* Import Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            استيراد البيانات
          </CardTitle>
          <CardDescription>
            رفع ملفات Excel لإضافة بيانات جديدة إلى النظام
          </CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Button
            onClick={() => handleImport('equipment')}
            variant="outline"
            className="h-16 flex flex-col gap-2"
          >
            <Settings className="h-5 w-5" />
            استيراد الأجهزة
          </Button>
          
          <Button
            onClick={() => handleImport('maintenance')}
            variant="outline"
            className="h-16 flex flex-col gap-2"
          >
            <FileText className="h-5 w-5" />
            استيراد سجلات الصيانة
          </Button>
        </CardContent>
      </Card>

      {/* Google Drive Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <HardDrive className="h-5 w-5" />
            Google Drive
          </CardTitle>
          <CardDescription>
            نسخ احتياطية تلقائية وإدارة التخزين السحابي
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <h3 className="font-medium">النسخ الاحتياطي التلقائي</h3>
              <p className="text-sm text-muted-foreground">
                يتم إنشاء نسخة احتياطية كل ساعة تلقائياً
              </p>
            </div>
            <Badge variant="default">نشط</Badge>
          </div>
          
          <Button
            onClick={handleDriveBackup}
            disabled={isBackingUp}
            className="w-full md:w-auto"
          >
            <HardDrive className="h-4 w-4 mr-2" />
            {isBackingUp ? "جاري الرفع..." : "إنشاء نسخة احتياطية الآن"}
          </Button>
        </CardContent>
      </Card>

      {/* System Info */}
      <Card>
        <CardHeader>
          <CardTitle>معلومات النظام</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between">
            <span>إصدار النظام:</span>
            <Badge variant="outline">1.0.0</Badge>
          </div>
          <div className="flex justify-between">
            <span>قاعدة البيانات:</span>
            <Badge variant="default">PostgreSQL</Badge>
          </div>
          <div className="flex justify-between">
            <span>التخزين السحابي:</span>
            <Badge variant="default">Google Drive</Badge>
          </div>
          <div className="flex justify-between">
            <span>النظام:</span>
            <Badge variant="secondary">مجاني ومفتوح المصدر</Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}