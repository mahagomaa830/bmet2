# نظام إدارة الأجهزة الطبية - Medical Equipment Management System

## تعليمات التشغيل / Installation Instructions:

1. تثبيت المتطلبات / Install dependencies:
```bash
npm install
```

2. إعداد قاعدة البيانات / Database setup:
- أنشئ قاعدة بيانات PostgreSQL / Create PostgreSQL database
- ضع رابط قاعدة البيانات في متغير البيئة / Set DATABASE_URL environment variable

3. دفع الجداول إلى قاعدة البيانات / Push schema to database:
```bash
npm run db:push
```

4. تشغيل الخادم للتطوير / Run development server:
```bash
npm run dev
```

5. تشغيل الخادم للإنتاج / Run production server:
```bash
npm run build
npm start
```

## إعداد Google Drive / Google Drive Setup:
1. إنشاء مشروع في Google Cloud Console
2. تفعيل Google Drive API  
3. إنشاء Service Account وتحميل ملف JSON
4. وضع مسار الملف في متغير البيئة GOOGLE_SERVICE_ACCOUNT_KEY

## ميزات النظام / System Features:
- نظام إدارة شامل للأجهزة الطبية / Comprehensive medical equipment management
- تتبع الصيانة والأعطال / Maintenance and fault tracking
- تصدير واستيراد البيانات من Excel / Excel import/export
- ربط تلقائي مع Google Drive / Automatic Google Drive sync
- واجهة عربية كاملة مع دعم RTL / Full Arabic interface with RTL
- نظام أذونات متعدد المستويات / Multi-level permissions
- تسجيل مستخدمين بدون كلمة مرور / Password-free user registration

## بيانات تجريبية / Demo Data:
- فني / Technician: الاسم "فني الأجهزة", الرقم "1" / Name "فني الأجهزة", ID "1"
- ممرضة / Nurse: الاسم "ممرضة القسم", الرقم "2" / Name "ممرضة القسم", ID "2"

هذا النظام مجاني ومفتوح المصدر بالكامل!
This system is completely free and open source!
