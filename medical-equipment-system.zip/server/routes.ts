import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import multer from "multer";
import { storage } from "./storage";
import { insertFaultReportSchema, insertMaintenanceRecordSchema, insertDailyCheckSchema, insertEquipmentNoteSchema } from "@shared/schema";
import { z } from "zod";
import {
  exportEquipmentToExcel,
  exportMaintenanceToExcel,
  exportFaultReportsToExcel,
  importEquipmentFromExcel,
  importMaintenanceFromExcel
} from "./excel";
import { googleDriveService } from "./google-drive";
import archiver from "archiver";

interface WebSocketClient {
  ws: WebSocket;
  userId?: number;
  role?: string;
}

const clients: Set<WebSocketClient> = new Set();

// Configure multer for file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || 
        file.mimetype === 'application/vnd.ms-excel') {
      cb(null, true);
    } else {
      cb(new Error('Only Excel files are allowed!'));
    }
  },
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { name, userId } = req.body;
      
      if (!name || !userId) {
        return res.status(400).json({ message: "Name and user ID required" });
      }

      const user = await storage.getUser(parseInt(userId));
      
      if (!user || user.name !== name) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      res.json({
        user: {
          id: user.id,
          name: user.name,
          role: user.role,
          department: user.department,
          email: user.email,
          phone: user.phone
        }
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const { name, email, phone, role, department } = req.body;
      
      if (!name || !role || !department) {
        return res.status(400).json({ message: "Name, role, and department required" });
      }

      const newUser = await storage.createUser({
        name,
        email,
        phone,
        role,
        department,
        isActive: true
      });

      res.json({ 
        user: { 
          id: newUser.id, 
          name: newUser.name, 
          role: newUser.role, 
          department: newUser.department,
          email: newUser.email,
          phone: newUser.phone
        }
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    res.json({ message: "Logged out successfully" });
  });

  // Export/Import/Drive routes
  app.get("/api/export/equipment", async (req, res) => {
    try {
      const buffer = await exportEquipmentToExcel();
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename="الأجهزة_الطبية.xlsx"');
      res.send(buffer);
    } catch (error) {
      console.error("Export equipment error:", error);
      res.status(500).json({ message: "Export failed" });
    }
  });

  app.get("/api/export/maintenance", async (req, res) => {
    try {
      const buffer = await exportMaintenanceToExcel();
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename="سجلات_الصيانة.xlsx"');
      res.send(buffer);
    } catch (error) {
      console.error("Export maintenance error:", error);
      res.status(500).json({ message: "Export failed" });
    }
  });

  app.get("/api/export/faults", async (req, res) => {
    try {
      const buffer = await exportFaultReportsToExcel();
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename="تقارير_الأعطال.xlsx"');
      res.send(buffer);
    } catch (error) {
      console.error("Export faults error:", error);
      res.status(500).json({ message: "Export failed" });
    }
  });

  app.post("/api/import/equipment", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const results = await importEquipmentFromExcel(req.file.buffer);
      res.json(results);
    } catch (error) {
      console.error("Import equipment error:", error);
      res.status(500).json({ message: "Import failed" });
    }
  });

  app.post("/api/import/maintenance", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const results = await importMaintenanceFromExcel(req.file.buffer);
      res.json(results);
    } catch (error) {
      console.error("Import maintenance error:", error);
      res.status(500).json({ message: "Import failed" });
    }
  });

  app.post("/api/drive/backup", async (req, res) => {
    try {
      const folderId = await googleDriveService.autoBackup();
      res.json({ message: "Backup completed", folderId });
    } catch (error) {
      console.error("Drive backup error:", error);
      res.status(500).json({ message: "Backup failed - check Google credentials" });
    }
  });

  app.get("/api/export/project-zip", async (req, res) => {
    try {
      const archive = archiver('zip', { zlib: { level: 9 } });
      
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="medical-equipment-system.zip"');
      
      archive.pipe(res);

      // Add all project files
      archive.directory('./client', 'client');
      archive.directory('./server', 'server');
      archive.directory('./shared', 'shared');
      archive.file('./package.json', { name: 'package.json' });
      archive.file('./package-lock.json', { name: 'package-lock.json' });
      archive.file('./vite.config.ts', { name: 'vite.config.ts' });
      archive.file('./tsconfig.json', { name: 'tsconfig.json' });
      archive.file('./tailwind.config.ts', { name: 'tailwind.config.ts' });
      archive.file('./postcss.config.js', { name: 'postcss.config.js' });
      archive.file('./drizzle.config.ts', { name: 'drizzle.config.ts' });
      archive.file('./components.json', { name: 'components.json' });

      // Add installation instructions
      const instructions = `# نظام إدارة الأجهزة الطبية - Medical Equipment Management System

## تعليمات التشغيل / Installation Instructions:

1. تثبيت المتطلبات / Install dependencies:
\`\`\`bash
npm install
\`\`\`

2. إعداد قاعدة البيانات / Database setup:
- أنشئ قاعدة بيانات PostgreSQL / Create PostgreSQL database
- ضع رابط قاعدة البيانات في متغير البيئة / Set DATABASE_URL environment variable

3. دفع الجداول إلى قاعدة البيانات / Push schema to database:
\`\`\`bash
npm run db:push
\`\`\`

4. تشغيل الخادم للتطوير / Run development server:
\`\`\`bash
npm run dev
\`\`\`

5. تشغيل الخادم للإنتاج / Run production server:
\`\`\`bash
npm run build
npm start
\`\`\`

## إعداد Google Drive / Google Drive Setup:
1. إنشاء مشروع في Google Cloud Console
2. تفعيل Google Drive API  
3. إنشاء Service Account وتحميل ملف JSON
4. وضع مسار الملف في متغير البيئة GOOGLE_SERVICE_ACCOUNT_KEY

## ميزات النظام / System Features:
- نظام إدارة شامل للأجهزة الطبية / Comprehensive medical equipment management
- تتبع الصيانة والأعطال / Maintenance and fault tracking
- تصدير واستيراد البيانات من Excel / Excel import/export
- ربط تلقائي مع Google Drive / Automatic Google Drive sync
- واجهة عربية كاملة مع دعم RTL / Full Arabic interface with RTL
- نظام أذونات متعدد المستويات / Multi-level permissions
- تسجيل مستخدمين بدون كلمة مرور / Password-free user registration

## بيانات تجريبية / Demo Data:
- فني / Technician: الاسم "فني الأجهزة", الرقم "1" / Name "فني الأجهزة", ID "1"
- ممرضة / Nurse: الاسم "ممرضة القسم", الرقم "2" / Name "ممرضة القسم", ID "2"

هذا النظام مجاني ومفتوح المصدر بالكامل!
This system is completely free and open source!
`;

      archive.append(instructions, { name: 'README.md' });
      
      await archive.finalize();
    } catch (error) {
      console.error("Project zip error:", error);
      res.status(500).json({ message: "ZIP creation failed" });
    }
  });
  
  // Equipment routes
  app.get("/api/equipment", async (req, res) => {
    try {
      const equipment = await storage.getAllEquipment();
      res.json(equipment);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch equipment" });
    }
  });

  app.get("/api/equipment/barcode/:barcode", async (req, res) => {
    try {
      const equipment = await storage.getEquipmentByBarcode(req.params.barcode);
      if (!equipment) {
        return res.status(404).json({ message: "Equipment not found" });
      }
      res.json(equipment);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch equipment" });
    }
  });

  app.get("/api/equipment/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const equipment = await storage.getEquipment(id);
      if (!equipment) {
        return res.status(404).json({ message: "Equipment not found" });
      }
      res.json(equipment);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch equipment" });
    }
  });

  app.patch("/api/equipment/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const equipment = await storage.updateEquipment(id, req.body);
      if (!equipment) {
        return res.status(404).json({ message: "Equipment not found" });
      }
      res.json(equipment);
    } catch (error) {
      res.status(500).json({ message: "Failed to update equipment" });
    }
  });

  // Fault Reports routes
  app.get("/api/fault-reports", async (req, res) => {
    try {
      const { status, priority } = req.query;
      let reports;
      
      if (status) {
        reports = await storage.getFaultReportsByStatus(status as string);
      } else if (priority) {
        reports = await storage.getFaultReportsByPriority(priority as string);
      } else {
        reports = await storage.getAllFaultReports();
      }

      // Enrich with equipment and user data
      const enrichedReports = await Promise.all(
        reports.map(async (report) => {
          const equipment = await storage.getEquipment(report.equipmentId);
          const reportedBy = await storage.getUser(report.reportedBy);
          const assignedTo = report.assignedTo ? await storage.getUser(report.assignedTo) : null;
          
          return {
            ...report,
            equipment,
            reportedByUser: reportedBy,
            assignedToUser: assignedTo,
          };
        })
      );

      res.json(enrichedReports);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch fault reports" });
    }
  });

  app.post("/api/fault-reports", async (req, res) => {
    try {
      const validatedData = insertFaultReportSchema.parse(req.body);
      const report = await storage.createFaultReport(validatedData);
      
      // Get equipment details for notification
      const equipment = await storage.getEquipment(report.equipmentId);
      const reportedBy = await storage.getUser(report.reportedBy);
      
      // Broadcast to all technician clients
      const notification = {
        type: "new_fault_report",
        data: {
          ...report,
          equipment,
          reportedByUser: reportedBy,
        },
      };
      
      broadcastToTechnicians(notification);
      
      res.json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create fault report" });
    }
  });

  app.patch("/api/fault-reports/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const report = await storage.updateFaultReport(id, req.body);
      if (!report) {
        return res.status(404).json({ message: "Fault report not found" });
      }
      
      // Broadcast update to relevant clients
      const notification = {
        type: "fault_report_updated",
        data: report,
      };
      
      broadcastToAll(notification);
      
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to update fault report" });
    }
  });

  // Maintenance Records routes
  app.get("/api/maintenance-records", async (req, res) => {
    try {
      const { equipmentId } = req.query;
      const records = await storage.getMaintenanceRecords(
        equipmentId ? parseInt(equipmentId as string) : undefined
      );
      
      // Enrich with equipment and technician data
      const enrichedRecords = await Promise.all(
        records.map(async (record) => {
          const equipment = await storage.getEquipment(record.equipmentId);
          const technician = await storage.getUser(record.technicianId);
          
          return {
            ...record,
            equipment,
            technician,
          };
        })
      );

      res.json(enrichedRecords);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch maintenance records" });
    }
  });

  app.post("/api/maintenance-records", async (req, res) => {
    try {
      const validatedData = insertMaintenanceRecordSchema.parse(req.body);
      const record = await storage.createMaintenanceRecord(validatedData);
      res.json(record);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create maintenance record" });
    }
  });

  app.patch("/api/maintenance-records/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const record = await storage.updateMaintenanceRecord(id, req.body);
      if (!record) {
        return res.status(404).json({ message: "Maintenance record not found" });
      }
      res.json(record);
    } catch (error) {
      res.status(500).json({ message: "Failed to update maintenance record" });
    }
  });

  // Daily Checks routes
  app.get("/api/daily-checks", async (req, res) => {
    try {
      const { date } = req.query;
      const checkDate = date ? new Date(date as string) : undefined;
      const checks = await storage.getDailyChecks(checkDate);
      
      // Enrich with equipment and technician data
      const enrichedChecks = await Promise.all(
        checks.map(async (check) => {
          const equipment = await storage.getEquipment(check.equipmentId);
          const technician = await storage.getUser(check.technicianId);
          
          return {
            ...check,
            equipment,
            technician,
          };
        })
      );

      res.json(enrichedChecks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch daily checks" });
    }
  });

  app.post("/api/daily-checks", async (req, res) => {
    try {
      const validatedData = insertDailyCheckSchema.parse(req.body);
      const check = await storage.createDailyCheck(validatedData);
      res.json(check);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create daily check" });
    }
  });

  // Equipment Notes routes
  app.get("/api/equipment/:id/notes", async (req, res) => {
    try {
      const equipmentId = parseInt(req.params.id);
      const notes = await storage.getEquipmentNotes(equipmentId);
      
      // Enrich with user data
      const enrichedNotes = await Promise.all(
        notes.map(async (note) => {
          const user = await storage.getUser(note.createdBy);
          return {
            ...note,
            createdByUser: user,
          };
        })
      );

      res.json(enrichedNotes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch equipment notes" });
    }
  });

  app.post("/api/equipment/:id/notes", async (req, res) => {
    try {
      const equipmentId = parseInt(req.params.id);
      const validatedData = insertEquipmentNoteSchema.parse({
        ...req.body,
        equipmentId,
      });
      const note = await storage.createEquipmentNote(validatedData);
      
      // Get user details for response
      const user = await storage.getUser(note.createdBy);
      
      res.json({
        ...note,
        createdByUser: user,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create equipment note" });
    }
  });

  app.delete("/api/equipment-notes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteEquipmentNote(id);
      
      if (!success) {
        return res.status(404).json({ message: "Note not found" });
      }
      
      res.json({ message: "Note deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete note" });
    }
  });

  // Statistics endpoint
  app.get("/api/statistics", async (req, res) => {
    try {
      const equipment = await storage.getAllEquipment();
      const faultReports = await storage.getAllFaultReports();
      
      const stats = {
        operational: equipment.filter(eq => eq.status === 'operational').length,
        maintenance: equipment.filter(eq => eq.status === 'maintenance').length,
        outOfService: equipment.filter(eq => eq.status === 'out_of_service').length,
        openReports: faultReports.filter(report => report.status === 'open').length,
        criticalReports: faultReports.filter(report => report.priority === 'critical').length,
        highPriorityReports: faultReports.filter(report => report.priority === 'high').length,
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket server setup
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocket, req) => {
    const client: WebSocketClient = { ws };
    clients.add(client);

    ws.on('message', (message: string) => {
      try {
        const data = JSON.parse(message);
        
        if (data.type === 'authenticate') {
          client.userId = data.userId;
          client.role = data.role;
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    });

    ws.on('close', () => {
      clients.delete(client);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(client);
    });
  });

  function broadcastToTechnicians(message: any) {
    clients.forEach(client => {
      if (client.ws.readyState === WebSocket.OPEN && client.role === 'technician') {
        client.ws.send(JSON.stringify(message));
      }
    });
  }

  function broadcastToAll(message: any) {
    clients.forEach(client => {
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify(message));
      }
    });
  }

  return httpServer;
}
